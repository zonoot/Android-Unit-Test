# android-unittest
Example of Unit testing on Android application


* Run test with output file
```
$gradle test --info
```

* Result

![alt tag](https://raw.githubusercontent.com/up1/android-unittest/master/result.png)
