package com.example.somkiat.myapplication;

public class Hello {
    public String say() {
        return "Hello";
    }
}
